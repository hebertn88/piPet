<?php

$host = "localhost";
$usuario = "root";
$senha = "";
$bd = "mydb";

$mysqli = mysqli_connect($host,$usuario,$senha,$bd);

if (!$mysqli){
    die("Conexão falhou: " . mysqli_connect_error());
}
?>