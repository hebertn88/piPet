<?php

  if (!isset($_SESSION)) session_start();

  include_once"conexao.php";

  $_SESSION['usuarioId'] = 1; //definindo usuario da sessao para teste

  if (!isset($_SESSION['usuarioId'])) {
       session_destroy();      
       header("Location: index.php"); exit;
  }
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>KD meu Pet? Cadastro de Animais</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    </head>
    <body>
        <nav class="navbar bg-light">
        </nav>
        <div class="container mt-3">
            <form action="/pipet/processa_cadastro_animais.php" method="post">
                <div class="mb-3">
                    <p>Qual a situação você deseja publicar?</p>
                    <div class="form-check form-check-inline">
                        <input type="radio" class="form-check-input" id="encontrado" name="situacao" value="1">
                        <label for="encontrado" class="form-check-label">Encontrei um animal</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input type="radio" class="form-check-input" id="perdido" name="situacao" value="2">
                        <label for="perdido" class="form-check-label">Meu animal está perdido</label>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="nome" class="form-label">Nome do Animal:</label>
                    <input type="text" class="form-control" maxlength="250" id="nome" name="nome" required>
                </div>
                <div class="mb-3">
                    <label for="foto" class="form-label">Envie uma foto:</label>
                    <input type="file" class="form-control" accept=".png, .jpg, .jpeg" id="foto" name="foto" required>
                </div>
                <div class="mb-3">
                    <label for="descricao" class="form-label">Descrição:</label>
                    <textarea rows="5" class="form-control" id="descricao" name="descricao" required></textarea>
                </div>
                <div class="mb-3">
                    <label for="tipo" class="form-label">Tipo do Animal: </label>
                    <select class="form-select" id="tipo" name="tipo">
                        <option selected>Selecione uma opção</option>
                        <?php 
                            $query = "SELECT * FROM cadastro_tipo ORDER BY t_nome ASC";
                            $sql = $mysqli->query($query) or die($mysqli->error);
                            while ($tp = $sql->fetch_array()){              
                        ?> 
                        <option name="<?php echo $tp["t_nome"]; ?>"
                            value="<?php echo $tp["t_id"]; ?>">
                            <?php echo $tp["t_nome"]; ?>
                        </option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="tamanho" class="form-label">Tamanho: </label>
                    <select class="form-select" id="tamanho" name="tamanho">
                        <option selected>Selecione uma opção</option>
                        <?php 
                            $query = "SELECT * FROM cadastro_tamanho ORDER BY t_nome ASC";
                            $sql = $mysqli->query($query) or die($mysqli->error);
                            while ($tm = $sql->fetch_array()){              
                        ?> 
                        <option name="<?php echo $tm["t_nome"]; ?>"
                            value="<?php echo $tm["t_id"]; ?>">
                            <?php echo $tm["t_nome"]; ?>
                        </option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="raca" class="form-label">Raça: </label>
                    <select class="form-select" id="raca" name="raca">
                        <option selected>Não Identificada</option>
                        <?php 
                            $query = "SELECT * FROM cadastro_raca ORDER BY r_nome ASC";
                            $sql = $mysqli->query($query) or die($mysqli->error);
                            while ($rc = $sql->fetch_array()){              
                        ?> 
                        <option name="<?php echo $rc["r_nome"]; ?>"
                            value="<?php echo $rc["r_id"]; ?>">
                            <?php echo $rc["r_nome"]; ?>
                        </option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="cor" class="form-label">Cor: </label>
                    <select class="form-select" id="cor" name="cor">
                        <option selected>Selecione uma opção</option>
                        <?php 
                            $query = "SELECT * FROM cadastro_cor ORDER BY c_cor ASC";
                            $sql = $mysqli->query($query) or die($mysqli->error);
                            while ($cr = $sql->fetch_array()){              
                        ?> 
                        <option name="<?php echo $cr["c_cor"]; ?>"
                            value="<?php echo $cr["c_id"]; ?>">
                            <?php echo $cr["c_cor"]; ?>
                        </option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
                <input type="submit" class="btn btn-primary" value="Enviar">
            </form>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    </body>
</html>