<?php

  if (!isset($_SESSION)) session_start();

  include_once"conexao.php";

  $_SESSION['usuarioId'] = 1; //definindo usuario da sessao para teste

  if (!isset($_SESSION['usuarioId'])) {
       session_destroy();      
       header("Location: index.php"); exit;
  }

/*
c_id int not null auto_increment,
c_nomeanimal varchar (250),
c_foto varchar (250),
c_descricao text,
c_usuario int,
c_raca int,
c_tamanho int,
c_situiacao int,
c_data datetime,
c_finalizado int,
*/
$nome = $_POST['nome'];
$foto = $_POST['foto'];
$descricao = $_POST['descricao'];
$usuario = $_SESSION['usuarioId']; 
$raca = $_POST['raca'];
$tamanho = $_POST['tamanho'];
$cor = $_POST['cor'];
$situacao = $_POST['situacao'];
$data = date('d-m-y h:i:s');
$finalizado = 0;

$query = "INSERT INTO `cadastro_animal` (`c_nomeanimal`, `c_foto`, `c_descricao`, `c_usuario`, `c_raca`, `c_tamanho`, `c_data`, `c_finalizado`, `id_cor`, `c_situacao`) VALUES ('$nome' , '$foto' , '$descricao' , $usuario , $raca , $tamanho , '$data' , $finalizado , $cor , $situacao)";

$mysqli -> query($query) or die ($mysqli -> error);

header('Location: /pipet/cadastro_animais.php');