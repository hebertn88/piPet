<?php

  if (!isset($_SESSION)) session_start();
  date_default_timezone_set('America/Sao_Paulo');

  include_once"conexao.php";

  $_SESSION['usuarioId'] = 1; //definindo usuario da sessao para teste

  if (!isset($_SESSION['usuarioId'])) {
       session_destroy();      
       header("Location: index.php"); exit;
  }


  if (isset($_FILES['foto'])) {
    $anexo = pathinfo($_FILES['foto']['name']);
    $extensao = strtolower($anexo['extension']);

    $ext_validas = array("jpeg", "jpg", "png");
    if (!in_array($extensao, $ext_validas)) { //se extensao nao for valida retorna
        $_SESSION["cadastro_animais"] = -1;   //a tela de cadastro animais com alerta erro
        header('Location: /pipet/cadastro_animais.php');
    }

    $novo_nome = md5(time()) . "." . $extensao;
    $diretorio = "upload/";
  }

  $nome = $_POST['nome'];
  $foto = $novo_nome;
  $descricao = $_POST['descricao'];
  $usuario = $_SESSION['usuarioId']; 
  $raca = $_POST['raca'];
  $tamanho = $_POST['tamanho'];
  $cor = $_POST['cor'];
  $situacao = $_POST['situacao'];
  $data = date('d-m-y h:i:s');
  $finalizado = 0;

  $query = "INSERT INTO `cadastro_animal` (`c_nomeanimal`, `c_foto`, `c_descricao`, `c_usuario`, `c_raca`, `c_tamanho`, `c_data`, `c_finalizado`, `id_cor`, `c_situacao`) VALUES ('$nome' , '$foto' , '$descricao' , $usuario , $raca , $tamanho , '$data' , $finalizado , $cor , $situacao)";

  if (move_uploaded_file($_FILES['foto']['tmp_name'], $diretorio.$novo_nome)) {
    $insert = $mysqli -> query($query);

    if ($insert){
        $_SESSION['cadastro_animais'] = 1; //arquivo e registro banco executado com sucesso
    } else {
        $_SESSION['cadastro_animais'] = -1; // erro ao inserir registro
    }
  } else {
    $_SESSION['cadastro_animais'] = -1; //erro ao mover arquivo
  }


header('Location: /pipet/cadastro_animais.php');